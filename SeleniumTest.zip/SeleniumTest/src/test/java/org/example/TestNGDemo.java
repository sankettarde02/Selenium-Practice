package org.example;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

import java.util.NoSuchElementException;

import javax.lang.model.element.Element;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class TestNGDemo {

	public WebDriver driver;

	@Test(priority = 1)
	public void testRegistrationLink() {
		driver.get("https://demo.guru99.com/test/newtours/");
		driver.findElement(By.xpath("//a[contains(@href, \"register.php\")]")).click();
		driver.findElement(By.xpath("//input[@name=\"firstName\"]")).sendKeys("Sanket");
		driver.findElement(By.xpath("//input[@name=\"lastName\"]")).sendKeys("Tarde");
		driver.findElement(By.xpath("//input[@name=\"phone\"]")).sendKeys("9604660308");
		driver.findElement(By.xpath("//input[@name=\"userName\"]")).sendKeys("sanket.tarde01@gmail.com");
		driver.findElement(By.xpath("//input[@name=\"address1\"]")).sendKeys("Flat No. 101, Rajgad, Hadapsar");
		driver.findElement(By.xpath("//input[@name=\"city\"]")).sendKeys("Pune");
		driver.findElement(By.xpath("//input[@name=\"state\"]")).sendKeys("Maharashtra");
		driver.findElement(By.xpath("//input[@name=\"postalCode\"]")).sendKeys("411028");
		Select dropselect = new Select(driver.findElement(By.xpath("//select[@name=\"country\"]")));
		dropselect.selectByVisibleText("INDIA");
		driver.findElement(By.xpath("//input[@name=\"email\"]")).sendKeys("sanket.tarde01@gmail.com");
		driver.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("123456789");
		driver.findElement(By.xpath("//input[@name=\"confirmPassword\"]")).sendKeys("123456789");
		driver.findElement(By.xpath("//input[@name=\"submit\"]")).click();
	}

	@Test(priority = 2)
	public void testLoginWithCorrectCredentials() {
		driver.findElement(By.xpath("//a[contains(@href, \"login.php\")]")).click();
		driver.findElement(By.xpath("//input[@name=\"userName\"]")).sendKeys("sanket.tarde01@gmail.com");
		driver.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("123456789");
		driver.findElement(By.xpath("//input[@name=\"submit\"]")).click();

	}

	@Test(priority = 3)
	public void validatePageAfterLogin() {
		assertEquals(driver.getCurrentUrl().contains("login_sucess"), true);
		WebElement ele = driver.findElement(By.xpath("//h3/*"));
		assertEquals(ele.getText(), "Login Successfully");
	}
	
	@Test(priority = 4)
	public void wrongCredentialsValidation() {
		driver.get("https://demo.guru99.com/test/newtours/");
		driver.findElement(By.xpath("//input[@name=\"userName\"]")).sendKeys("sanket.tarde01@gmail.com");
		driver.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("ss123456789");
		driver.findElement(By.xpath("//input[@name=\"submit\"]")).click();
		Boolean isPresent = isElementPresent("//span");
		if (isPresent) {
			assertEquals(driver.findElement(By.xpath("//span")).getText(), "Enter your userName and password correct");
		}
	}

	@BeforeTest
	public void beforeTest() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\jbk\\workspace1\\SeleniumTest\\src\\main\\java\\org\\example\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@AfterTest
	public void afterTest() {
		driver.quit();
	}

	private boolean isElementPresent(String xPath) {
	    try {
	    	driver.findElement(By.xpath(xPath));
	    } catch (NoSuchElementException e) {
	        return false;
	    }
	    return true;
	}
}
